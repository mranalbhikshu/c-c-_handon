#include<iostream>
using namespace std;

typedef class{
    int value;
    public:
    void setdata(int i){this->value = i;}
    void printvalues(){cout<<"value of i:"<<this->value<<endl;}
}myclass;

class A : public myclass{
    public: 
    A(){
        setdata(20);
        printvalues();
    }
};

int main(){
    myclass obj1, obj2;
    obj1.setdata(12);
    obj1.printvalues();
    obj2.setdata(80);
    obj2.printvalues();
    A a;
    return 0;
}