#include<iostream>
using namespace std;

class Base{
      public:
      Base(){
        cout<<"construtor of Base"<<endl;
      }
      virtual void Display()
      {
        cout<<"Display of Base"<<endl;
      }
    ~Base(){
        cout<<"destructor of Base"<<endl;
      }

};

class Derived:public Base{
    public:
    Derived(){
        cout<<"construtor of Derived"<<endl;

    }
    void Display(){
        cout<<"Display of Derived"<<endl;
    }
    ~Derived(){
        cout<<"destructor of Derived"<<endl;

    }
};

class Derived2 :public Derived{
    public:
    Derived2(){
        cout<<"constructor of Derived2"<<endl;
    }
    void Display(){
        cout<<"Display of Derived2"<<endl;
    }
    ~Derived2(){
        cout<<"Destuctor of Derived2"<<endl;
    }
};

int main(){
    Base *p = new Derived();
    p->Display();
    delete p;
}