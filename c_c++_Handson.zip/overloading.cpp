#include<iostream>
using namespace std;

int function(float){
    cout<<"type-float"<<endl;
    return 0;

}

int function(int){
    cout<<"type-int"<<endl;
    return 0;

}

int main(){
    function(1.0f);
    function(1);
    function(1.0f);
    function(1);
    return 0;
}