#include<iostream>
using namespace std;

int x = 20;
namespace outer
{
int x = 10;    
namespace inner;
{
    int z = z;
}
}

int main(){
    cout<<outer::inner::z;
    getchar();
    return 0;
}