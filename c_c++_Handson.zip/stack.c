#include<stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct Node *next;

};

struct node *front = NULL;
struct node *rear = NULL;

void initializeQueue(){
    front = NULL;
    rear = NULL;
}

int size();

void insertQueue(int data){
    struct node *temp;
    temp = (struct node *)malloc(sizeof(struct node));
    temp->data=data;
    temp->next=NULL;
    if(front==NULL)
    {
        front = temp;
    }
    

    else{
        rear->next=temp;
    }
    

    }

    void deleteQueue(){
        struct node *temp = front;
        front = front->next;
        free(temp);
    }
    void isEmpty(){
        if(front == NULL){
            printf("Empty");
        }
        else{
            printf("Not Empty");
        }
    }
    Void peek(){
        if(front == NULL){
            printf("Empty!");
        }
        else{
            printf("%d",front->data);
        }

    }

    void print(){
        struct node *temp = front;
        while(temp != NULL)
        {
            if(temp->next==NULL)
            printf("%d",temp->data);
            else
            printf("%d",temp->data);
            temp=temp->next;
        }
    }

    void main()
    {
        isEmpty();
        printf("\n");
    
        peek();
        printf("\n");
        insertQueue(20);
        insertQueue(25);
        insertQueue(2);
        insertQueue(29);
        insertQueue(30);
        print();
        printf("\n");
        isEmpty();
        printf("\n");
        peek();
        deleteQueue();
        printf("\n");
        printf("\n");
        print();
    }
    
