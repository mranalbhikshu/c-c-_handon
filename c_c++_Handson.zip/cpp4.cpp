#include<iostream>
using namespace std;
namespace first{
    double x = 5.1416;
    double y = 3.7183;

}
namespace second{
    double x = 3.1416;
    double y = 2.7183;

}

int main(){
    using namespace first;
    cout<<x<<endl;
    cout<<y<<endl;
    cout<<second::x<<endl;
    cout<<second::y<<endl;
    return 0;
}