#include<iostream>
using namespace std;

class car{
    public:
    virtual void start() =0;
    virtual void stop() =0;

    car(){}
    virtual ~car() = 0;
    
};

class Innova: public car{
    public:
    void start(){
        cout<<"Innova started"<<endl;


    }
    void stop(){
        cout<<"Innova stopped"<<endl;
    }
    Innova(){}
    ~Innova(){
        cout<<"Destructor of swift"<<endl;
    }
};

class swift: public car{
    public:
    void start(){
        cout<<"swift started"<<endl;

    }
    void stop(){
        cout<<"swift stopped"<<endl;
    }
    swift(){}
    ~swift(){
        cout<<"Destructor of swift"<<endl;
    }
};

int main(){
    car *c = new Innova();
    c->start();
    c->stop();
    delete c;
    c = new swift();
    c->start();
    c->stop();
    delete c;
}