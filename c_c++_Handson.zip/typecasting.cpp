#include<iostream>
using namespace std;

int main(){
    int i = 5;
    float p = i;

    cout<<p<<endl;

    float o = 9;
    int h = o;
    cout<<h;
     return 0;

}

