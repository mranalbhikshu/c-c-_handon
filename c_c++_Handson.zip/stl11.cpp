#include<iostream>
#include<set>
using namespace std;

int main(){
    map<int, string>sample_map;
    sample_map.insert(pair<int, string>(1, "one"));
    sample_map.insert(pair<int, string>(2, "two"));

    return 0;
}