#include<iostream>
using namespace std;
class A{
  public:
    class B{
        public:
        virtual void fun(){
        cout<<"hello";
    }
    
    };
    

    class C : public B{
        public:
            B y;
            void fun(){
            cout<<"hello2";
    }

        
    };
};


int  main(){
    A::B* c = new A::C();
    c->fun();



}