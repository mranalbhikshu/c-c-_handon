#include<iostream>
using namespace std;

class overload{
    private:
    int a;
    int b;
    
    public:
    overload():a(0),b(0){}

    void in(){
        cout<<"Enter the first number: ";
        cin>>a;
        cout<<"Enter the second number: ";
        cin>>b;

    }
    
    void operator--(){
        a = --a;
        b = --b;
    }

    void out(){
        cout<<"The decremented elements of then objects:"<<a<<", "<<b<<endl;
    }
};

int main(){
    overload obj;
    obj.in();

    --obj;
    obj.out();

    return 0;
}