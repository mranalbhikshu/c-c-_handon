#include<stdio.h>
#include<string.h>

int main(){
    char name[50];
    printf("Enter the Name:");
    scanf("%s",name);
    printf("Your name is %s.",name);
    return 0;
}