#include<iostream>
using namespace std;

int main(){


    int i, j, n;
    cout<<"Enter number of two element"<<endl;
    cin>>n;
    int a[n], b[n], c[n][n];
    cout<<"Enter First Array"<<endl;
    for (i=0;i<n;i++)
    {
        cin>>a[i];
    }
    cout<<"Enter Second Element"<<endl;
    for(j=0;j<i;j++)
    {
            cin>>b[j];
    }

    

    for(i=0;i<n;i++)
    {
       for(j=0;j<n;j++)
       {
        c[i][j]= a[i]*b[j];
       }
       
    }
    cout<<"Multiplication is"<<endl;
    for(i=0;i<n;i++)
    {
       for(j=0;j<n;j++)
       {
        cout<<c[i][j]<<" ";
       }
       cout<<endl;
    }

    

    for(i=0;i<n;i++)
    {
       for(j=0;j<n;j++)
       {
        c[i][j]= a[i]+b[j];
       }
      
    }
    cout<<"Addition is"<<endl;
    for(i=0;i<n;i++)
    {
       for(j=0;j<n;j++)
       {
        cout<<c[i][j]<<" ";
       }
       cout<<endl;
       
    }

    

    for(i=0;i<n;i++)
    {
       for(j=0;j<n;j++)
       {
        c[i][j]= a[i]-b[j];
       }
       
    }
    cout<<"Subtraction is"<<endl;

    for(i=0;i<n;i++)
    {
       for(j=0;j<n;j++)
       {
        cout<<c[i][j]<<" ";
       }
       cout<<endl;
    }   

    
        
}