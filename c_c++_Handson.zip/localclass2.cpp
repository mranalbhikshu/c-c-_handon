#include<iostream>
using namespace std;

void fun(){
        class local
        {
            public:
            int fun(){cout<<"this is testing";return 0;};

            int g(){return 0;}

            //static int a;

            int b ;

        };
        local l;
        l.fun();
        
        /*local::fun(){
            cout<<"this is testing";
            return 0;
        }*/
}
int main(){
    fun ();
    return 0;
}
