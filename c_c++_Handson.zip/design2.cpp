#include<iostream>
#include<string>
using namespace std;
class poingable{
    public:
    virtual void poing() = 0;
};

void callpoing(Poingable& p){
    p.poing();
}



class Bingable{
    public:
    virtual void bing() = 0;
};

void callbing(Bingable& b){

    b.bing();
}

class Outer{
    string name;
    class Inner1;
    friend class outer::Inner1;
    class Inner1: public poingable{
        Outer *parent;
        public:
        Inner1(outer *p):parent(p){}
        void poing(){
            cout<<"poing called for "<<parent->name<<endl;
        }
    }inner1;

    class Inner2;
    friend class outer::Inner2;
    class Inner2 : public Bingable{
        outer* parent;
        public:
        Inner(Outer *p):parent(p){}
        void bing(){
            cout<<"bing called for"<<parent->name<<endl;
        }
    }inner2;
    public:
    Outer(const string& nm)
    :name(nm), inner1(this), inner2(this){}

    operator Poingable&() {return inner1;}
    operator Bingable&() {return inner2;}



};

int main(){
    Outer x("Ping POng");
    callpoing(x);
    callbing(x);
}