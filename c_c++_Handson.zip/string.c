#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main(){
char ch[11]={'a','b','d','r','t','y','u','f','d','d','e'};
char ch2[12]="agvyhrguji";
printf("the first string is :%s\n",ch);
printf("the second string is :%s",ch2);
}