#include<iostream>
using namespace std;

void greet()
{
    cout<<"Hello World";
}

int main()
{
    greet();
    return 0;
}