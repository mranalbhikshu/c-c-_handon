#include<stdio.h>
int main(){
int i,j;
int sum=0;
scanf("%d%d",&i,&j);
sum=i+j;
printf("the sum is: %d",sum);
return 0;
}
