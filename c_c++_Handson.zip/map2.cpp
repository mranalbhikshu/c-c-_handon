#include<iostream>
#include<set>
using namespace std;
int main(){
    map<int, string>sample_map{{1,"one"},{2, "two"}};
    sample_map[3] = "three";

    sample_map.insert()
}