#include<iostream>
using namespace std;
class classB;
class classA{
    public:
    classA() : numA(12){}

    private:

    int numA;
    friend classB;
};

class classB{
    public:
    classB() : numB(1){}
    int add(){
        classA objectA;
    return objectA.numA +numB;
}

    private:

    int numB;
    
};



int main(){
    classA objectA;
    classB objectB;
    cout<<"Sum : "<<objectB.add();
    return 0;

}