#include<iostream>
using namespace std;
class address{
    char address_customer[70];
    cout<<"Enter the address of the customer :";
    cin.getline(address_customer, sizeof(address_customer));
}
class bankaccount{
    int name[50];
    

};
int main()
{

}