#include<iostream>
using namespace std;

class car{
    public:
    virtual void start() =0;
    virtual void stop() =0;

    void Horn(){
        cout<<"Blow Horn"<<endl;
    }
};

class Innova: public car{
    public:
    void start(){
        cout<<"Innova started"<<endl;


    }
    void stop(){
        cout<<"Innova stopped"<<endl;
    }
};

class swift: public car{
    public:
    void start(){
        cout<<"swift started"<<endl;

    }
    void stop(){
        cout<<"swift stopped"<<endl;
    }
};

int main(){
    car *c = new Innova();
    c->start();
    c->stop();
    c->Horn();
    c = new swift();
    c->start();
    c->stop();

}