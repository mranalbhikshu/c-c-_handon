#include<isotream>
using namespace std;
class Poingable