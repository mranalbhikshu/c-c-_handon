#include<iostream>
using namespace std;

class class_1
{
    public:
    int x = 3;
};

class class_2: private class_1{
    public: 
    int y=6;

};

//class 3

class class_3 : public class_1
{
  public:
  int z = 6;



};
class Derived_class : public class_2, public class_3{
    public:
    int i = class_2::x;

void sum(){
    cout<<"the sum of Numbers is : "<<i+y+z<<endl;
}

};

int main(){
    Derived_class ob;
    ob.sum();
    return 0;
}