#include<iostream>
using namespace std;


int add(int a){
    int b = 10;
    return a+b;
    
}
int add(int a, int b ){
    return a + b;
}
int main(){

    int a = 9,b=10;
    cout<<b<<endl;
    cout<<add(a,b)<<endl;
}