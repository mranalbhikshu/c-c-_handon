#include<iostream>
using namespace std;

struct x{
    int x;
    double y;
    char c;
    bool b;
};

int main(){
    struct x f;
    f.x = 10;
    f.c ='A';
    f.b = true;
    double o ;
    int *p = reinterpret_cast<int*>(&f);
     

    cout<<sizeof(f)<<endl;
    cout<<sizeof(o)<<endl;
    cout<<*p<<endl;
    int *p = reinterpret_cast<int*>(p);
    cout<<*ch<<endl;

    bool* n = reinterpret_cast<int*>(p);

    }