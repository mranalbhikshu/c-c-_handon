#include<stdio.h>
#include<stdlib.h>
union unionJob
{
char name[20];
float salary;
int workerNo;
}uJob;
struct unionJob
{
char name[32];
float salary;
int workerNo;
}sJob;
int main(){
printf("size of union= %lu bytes",sizeof(uJob));
printf("\nsize of structure =%lu bytes",sizeof(sJob));
return 0;
}

