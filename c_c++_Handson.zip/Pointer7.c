#include<stdio.h>
int main(){
    char *str;
    {
        char a='A';
        str=&a;

    }
    // a falls out of scope
    // str is now a dangling pointers

    printf("%c",*str);
}