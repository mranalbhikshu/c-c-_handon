#include<iostream>
using namespace std;
class a{
void sum(){
    public:
    int x;
    cout<<"sum"<<endl;
}
};

class b : public a{
        public:
        a obj;
        a.sum();
        sum();
        int y;
        b(){
            sum();
        }
        void run(){
            return sum();
        }
};        

int main(){
    

}