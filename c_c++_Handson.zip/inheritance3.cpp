#include<iostream>
using namespace std;

class Baseclass{

    public:
    void print(){
        cout<<"This is an Example of Multilevel inheritance";
    }
};

class Derivedclass: public Baseclass{};

class Derivedclass2: public Derivedclass{};

int main(){
    Derivedclass2 obj;
    obj.print();
}