#include<iostream>
using namespace std;

class myclass{
    public:
    int myNum;
    string mystring;

};

int main(){

    myclass myobj;

    myobj.myNum =15;
    myobj.mystring = "some text";

    cout<<myobj.myNum<<'\n';
    cout<<myobj.mystring<<'\n';
    return 0;
}