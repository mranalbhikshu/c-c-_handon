#include<iostream>
using namespace std;
typedef unsigned char BYTE;

void f(){
    char ch;
    int i = 65;
    float f =25;
    double dbl;

    ch = static_cast<char>(1);
    dbl = static_cast<double>(f);
    i = static_cast<BYTE>(ch);
    cout<<"i am the best";
    }
int main(){
    f();
}