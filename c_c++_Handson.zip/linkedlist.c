#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>


struct Node{
    int data;
    struct Node *next;
};
struct Node *head=NULL;

bool loop(struct Node* head){
    struct Node * slow,*fast;
    slow=head;
    fast=head;
    while(fast!=NULL&& fast->next!=NULL){
        slow = slow->next;
        fast = fast->next->next;
    
    if(slow==fast)
    return true;
    }
    return false;
}
/*void print_linkedlist(struct Node* start){
    
        while(start!=NULL){
            printf("%d\n",start->data);
            start=start->next;
        }
    
}
struct Node *insertInorder(struct Node *start,int data){
    struct Node *p,*temp;
    temp=(struct Node*)malloc(sizeof(struct Node));
    temp->data=data;
    if(start==NULL||data<start->data){
        temp->link=start;
        start=temp;
        return start;
    }
}*/
Void reverse(){
    Struct Node* prev= NULL;
    Struct Node* next1= NULL;
    Struct Node* curr= NULL;
    while(curr!=NULL){
        next1=curr->next;
        curr->next=prev;
        prev=curr;
        curr=next1;
    }
    head=prev;
    
}



int main(){

    struct Node* temp1=(struct Node*)malloc(sizeof(struct Node));
    struct Node* temp2=(struct Node*)malloc(sizeof(struct Node));
    struct Node* temp3=(struct Node*)malloc(sizeof(struct Node));
    head = temp1;
    temp1->data=10;
    temp2->data=20;
    temp3->data=30;
    temp1->next=temp2;
    temp2->next=temp3;
    temp3->next=head;



    bool result=loop(head);
    if(result==true)
    printf("loop exist");
    else
    printf("loop not exist");
    //print_linkedlist(head);
    //insert_end(40);
    //printf("\n");
    //print_linkedlist(head);
    //delete(2);
    //print_linkedlist(head);
    return 0;

}
