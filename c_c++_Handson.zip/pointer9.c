#include<stdio.h>
int addition(){
    int a,b;
    printf("ENter two numbers");
    scanf("%d %d ",&a,&b);
    return (a+b);
}
int substraction(){
    int a,b;
    printf("Enter two Number ");
    scanf("%d %d ",&a,&b);
    return(a-b);
}
int greaterthan100(int a){
    printf("Enter a Number");
    scanf("%d",&a);
    if(a>100){
        printf("the number is greater than 100");
    }
    else{
        printf("your Number is not greater than 100");
    }
}
int square(int a){
    return a*a;
}


int main(){
    int result;
    int (*ptr)();
    ptr= &addition;
    result =  (*ptr)();
    printf("the sum is %d",result);  
    ptr= &substraction;
    result =  (*ptr)();
    printf("the substraction is %d",result);
    ptr= &square;
    result =  (*ptr)(4);
    printf("the square is %d",result);                                                                                                                                        
}