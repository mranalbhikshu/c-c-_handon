#include<iostream>
using namespace std;

void byvalue_age_in_5_years(int age)
{
    age+=5;
    cout<<"Age in 5 years: "<<age<<endl;

}

int main(){
    int age = 95;
    byvalue_age_in_5_years(age);

    cout<<"current age: "<<age;
    return 0;
}