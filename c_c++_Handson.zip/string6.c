#include<stdio.h>
#include<string.h>
int main(){
    char str[20];
    printf("Enter String:");
    scanf("%s",str);
    printf("string is:%s",str);
    printf("\nUpper string is %s:",strupr(str));
    return 0;
}