#include<stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node *next;

};

struct node *front = NULL;
struct node *rear = NULL;



void insertQueue(int data){
    struct node *temp;
    temp = (struct node*)malloc(sizeof(struct node));
    if(temp == NULL)
    printf("Memory not available");
    temp->data=data;
    temp->next=NULL;
    if(front==NULL)
    {
        front = temp;
    }
    

    else{
        rear->next=temp;
    }
    
    rear = temp;
    }

    void deleteQueue(){
        struct node *temp = front;
        front = front->next;
        free(temp);
    }
    void isEmpty(){
        if(front == NULL){
            printf("Empty");
        }
        else{
            printf("Not Empty");
        }
    }
    void peek(){
        if(front == NULL){
            printf("Empty!");
        }
        else{
            printf("%d",front->data);
        }

    }

    void print(){
        struct node *temp = front;
        while(temp != NULL)
        {
            if(temp->next==NULL)
            printf("%d",temp->data);
            else
            printf("%d",temp->data);
            temp=temp->next;
        }
    }

    void main()
    {
        isEmpty();
        printf("\n");
    
        peek();
        printf("\n");
        insertQueue(20);
        printf("\n");
        insertQueue(25);
        printf("\n");
        insertQueue(2);
        printf("\n");
        insertQueue(29);
        printf("\n");
        insertQueue(30);
        printf("\n");
        print();
        printf("\n");
        isEmpty();
        printf("\n");
        peek();
        deleteQueue();
        printf("\n");
        printf("\n");
        print();
    }
    
