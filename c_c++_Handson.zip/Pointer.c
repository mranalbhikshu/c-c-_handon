#include<stdio.h>
#include<stdlib.h>
int main(){
    int x;

    //print address of x
    printf("%p",&x);

    return 0;

}