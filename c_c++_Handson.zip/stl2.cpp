#include<iostream>
using namespace std;

int main(){

    vector<int>a;

    for(int i = 1;i<=10; i++)
        a.push_back(i*10);

    cout<<"\n Reference operator [g] : a[2] = "<<a[2];

    cout<<"\n at: a.at(4):"<<a.at(4);

    cout<<"\n back(): a.back() = "<<a.back();

    int * pos = a.data;

    cout<<"\n back(): a.back() = "<<a.back();

    int *pos = a.data();

    cout<<"\n The first element is "<<*pos;

    return 0;
}