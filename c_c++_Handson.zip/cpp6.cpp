#include<iostream>
using namespace std;
namespace addition{
    int operation()
    {
        int x,y;
        cin>>x>>y;
        return x+y;
    }
}
namespace substraction{
    int operation()
    {
        int x,y;
        cin>>x>>y;
        return x-y;
    }
}
namespace multi{
   int operation()
    {
        int x,y;
        cin>>x>>y;
        return x*y;
    }
}
namespace division{
    int operation()
    {
        int x,y;
        cin>>x>>y;
        return x/y;
    }
}

int main(){
    
    cout<<addition::operation()<<endl;
    cout<<substraction::operation()<<endl;
    cout<<multi::operation()<<endl;
    cout<<division::operation()<<endl;

 return 0;
}