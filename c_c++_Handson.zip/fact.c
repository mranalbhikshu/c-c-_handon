#include<stdio.h>
int fact(int n){
    if(n>=1){
        return n*fact(n-1);
    }
   
    else{
        preturn 1;
    }

}
int main(){
    int n;
    scanf("the number is : %d",&n);
    
    printf("%d",fact(n));

}