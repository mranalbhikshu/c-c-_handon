#include<stdio.h>
#include<string.h>

int main(){
    char str[50]="this is\t", str2[]="c SESSIOn";
    strcat(str,str2);
    puts(str);
    puts(str2);
    return 0;
}