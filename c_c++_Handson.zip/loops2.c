#include<stdio.h>
struct struct
