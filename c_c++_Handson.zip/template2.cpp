#include<iostream>
using namespace std;

template<class T, class U>
bool are_equal(T a, U b)
{
    return(a==b);
}

int main()
{

    if(are_equal(10,10.0))
    cout<<"X and Y are equal\n";
    else
    cout<<"X and Y are not equal\n";

    return 0;
}