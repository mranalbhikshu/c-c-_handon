#include<stdio.h>
#include<stdlib.h>
struct node{
    int info;
    struct node *link;

};
struct node* top = NULL;
struct node* bottom =NULL;

void push(int data){
    struct node *temp;
    temp= (struct node*)malloc(sizeof(struct node));
    if(temp == NULL){
        printf("Memory not Available");
    }
    temp->info=data;
    temp->link=top;
    top=temp;
}

void pop(){
    if(top==NULL){
        printf("stack is Empty");
        return;
    }
    struct node *temp = top;
    top = top->link;
    free(temp);
}

int isEmpty(){
    if(top == NULL){
        printf("Empty");
        return 1;
    }
    else{
        printf("Not Empty");
        return 0;
    }
}

void peek(){
    if (top==NULL){
        printf("Empty");
    }
    else{
        printf("%d",top->info);

    }
}


void print(){
    struct node *temp = top;
    while(temp!=NULL){
        printf("%d",temp->info);
        temp = temp->link;
    }
}



void main(){
    isEmpty();
    printf("\n");
    push(12);
    printf("\n");
    push(4);
    printf("\n");
    push(34);
    printf("\n");
    pop();
    print();
    printf("\n");
    peek();
    printf("\n");
    
}