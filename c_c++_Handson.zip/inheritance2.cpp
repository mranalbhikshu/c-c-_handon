#include<iostream>
using namespace std;

class Base1{
   

    public:
    float salary = 90000;

};
class Base2{
    public:
    float bonus = 5000;
};

class Derived: public Base1, public Base2{
    public: 
    
    void sum(){
        cout<<"your total salary is: "<<(salary + bonus)<<endl;
    }
};

int main()
{   Derived x;
    
    x.sum();
    return 0;
}