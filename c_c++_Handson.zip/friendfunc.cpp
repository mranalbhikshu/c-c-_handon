#include<iostream>
using namespace std;
class classB;
class classA{
    public:
    classA() : numA(12){}

    private:

    int numA;
    friend int add(classA, classB);
};

class classB{
    public:
    classB() : numB(1){}

    private:

    int numB;
    friend int add(classA, classB);
};

int add(classA objectA, classB objectB){
    return(objectA.numA + objectB.numB);
}

int main(){
    classA objectA;
    classB objectB;
    cout<<"Sum : "<<add(objectA, objectB);
    return 0;

}

