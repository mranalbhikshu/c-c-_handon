#include<iostream>
using namespace std;

int count = 0;
class test{
    public:
    test()
    {
        count++;
        cout<<"\n No.of object created: "<<count;
    }

    ~test()
    {
        cout<<"\n No. of object destroyed:\t"<<count;
        --count;
    }
};

int main()
{
    test t, t1, t2,t3;
    return 0;
}
