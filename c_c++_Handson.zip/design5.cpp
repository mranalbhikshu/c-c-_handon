#include<iostream>
using namespace std;
 class A{
    public:
    //int x=10;
    //int y = 40;
    int x;
    int y;
    A()= x(10),y(40){}

 };

 int main(){
     A a;
    cout<<a.x<<endl<<a.y<<endl;
 }
