#include<stdio.h>
#include<stdlib.h>
struct Point{
int X,Y;
};
int main(){
struct Point arr[10];
arr[0].X=10;
arr[0].Y=20;
printf("%d %d",arr[0].X,arr[0].Y);
return 0;
}
