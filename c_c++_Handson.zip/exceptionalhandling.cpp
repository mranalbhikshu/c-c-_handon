#include<iostream>
using namespace std;

int main(){

    int a;
    int b;
    cout<<"Enter Two Numbers: ";
    cin>>a>>b;
    try{
        if(b==0){
            throw b;
        }
        else{
            cout << (a/b) << endl;
        }
    
    }
    catch(float ex){
        cout<<"Float exception catch:"<<(a/b);
    }
    catch(...){
        cout<<"Default Exception catch";
    }

    return 0;
}
