#include<iostream>
#include<vector>
using namespace std;

int main(){
    vector<int> a;
    for(int i = 1; i<=5; i++)
    a.push_back(i);

    cout<<"size: "<<a.size();

    cout<<"\ncapacity: "<<a.capacity()<<endl;
    
    cout<<"\nMax_Size: "<<a.max_size()<<endl;

    cout<<"\nsize: "<<a.size()<<endl;

    for(int i=5;i>=1;i--)
        a.pop_back(i);

    if (a.empty()==false)
        cout<<"\nVector is not Empty: ";

    else
        cout<<"\n Vector is Empty: ";    

    return 0;
}