class B{};
class D : public B{};

void f(B* pb, D* pd){
    D* pd2 = static_cast<D*>(pb);

    B* pd2 = static_cast<D*>(pd);
}

int main(){
    
}