#include<iostream>
using namespace std;

class Base{
    public:
    float salary = 90000;
};

class Derived: public Base{
    public: 
    float bonus = 5000;
    void sum(){
        cout<<"your total salary is: "<<(salary + bonus)<<endl;
    }
};

int main()
{   Derived x;
    cout<<"Your Salary is: "<<x.salary<<endl;
    cout<<"your Bonus is: "<<x.bonus;
    x.sum();
    return 0;
}