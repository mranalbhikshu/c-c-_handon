#include<stdio.h>
#include<stdlib.h>
int main(){
    int *pc, c;
    c=23;
    printf("Address of C: %p\n", &c);
    printf("Value of c : %d\n\n",c);//23

    pc=&c;
    printf("address of Pointer pc: %p\n", pc);
    printf("content of pointer pc: %d\n\n",*pc);

    c=11;
    printf("Address of C: %p\n", pc);
    printf("content of pointer pc : %d\n\n",*pc);//2

    *pc=2;
    printf("Address of C: %p\n", &c);
    printf("Value of c : %d\n\n",c);//2

    return 0;
}