#include<iostream>
#include<list>
#include<iterator>

using namespace std;
void ShowTheContent(list<int>l)
{
    list<int>::iterator it;
    for(it = l.begin();l.end();it++)
    {
        cout<<*it<" ";

    }
    cout<<"\n";
}

int main(){
    list<int> list1,list2;
    int i;
    for(i =0;i<10;i++)
        list1.push_back(i+1);

    for(i=0;i<10;i++)
        list2.push_front(i+1);

    cout<<"Content of List1 : ";
    ShowTheContent(list1);
    cout<<"Content of List2 : ";
    ShowTheContent(list2);

    int times = 5;
    while(times--)
    {
        list1.pop_front();
    }

    cout<<"Content of List1 : ";
    ShowTheContent(list1);

    times = 5;
    while(times--){
        list2.pop_back();
    }
    cout<<"Content of List 2 : ";
    ShowTheContent(list2);

    cout<<list1.front()<<"is now at the front in list\n";

    cout<<list2.back()<<"is now the last elements in list\n";

    list1.insert(list1.begin(),5,10);
    cout<<"After Insertion list 1 : ";
    ShowTheContent(list1);

    list1.remove(10);
    cout<<"After Removal list 1: ";
    ShowTheContent(list1);

    cout<<"No. of elements in list1: ";
    cout<<list1.size()<<"\n";
    list2.reverse();
    cout<<"Reversed list 2 : ";
    ShowTheContent(list2);
    

    list2.erase(list2.begin());
    cout<<"After erasing from list2: ";
    ShowTheContent(list2);

    list1.clear();
    if(list1.empty())
        cout<<"List 1 is now Empty\n";
    else
        cout<<"Not Empty\n";

        list1.assign(5,2);
        cout<<"List 1: ";
        ShowTheContent(list1);
        return 0; 

    
}