#include<iostream>
using namespace std;

int x = 10;
void fun()
{
    static int x =20;
    }
