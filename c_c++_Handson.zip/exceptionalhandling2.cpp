#include<iostream>

using namespace std;
 int test(int x){
    try{
        if(x>0)
        throw x;
        else
        throw 'x';

    }catch(int x){
        cout<<"Catch a integer and that integer i"
    }
    catch(char){
        cout<<"Catch a charater and that character ";
        
    }
 }

 int main(){
    cout<<"Testing multiple cathes\n";
    cout<<"Hi";
    test(10);
    test();
    
    return 0 ;
 }